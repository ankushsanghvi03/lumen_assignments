echo "=================================="
echo "      ONLINE FOOD MENU"
echo "=================================="
echo "1. Pizza      - Rs.250"
echo "2. Burger     - Rs.120"
echo "3. Sandwich   - Rs.100"
echo "4. Pasta      - Rs.180"
echo "5. Fries      - Rs.80"
echo "=================================="

echo -n "Enter your choice (1-5): "
read choice

case $choice in
    1)
        food="Pizza"
        price=250
        ;;
    2)
        food="Burger"
        price=120
        ;;
    3)
        food="Sandwich"
        price=100
        ;;
    4)
        food="Pasta"
        price=180
        ;;
    5)
        food="Fries"
        price=80
        ;;
    *)
        echo "Invalid Choice"
        exit
        ;;
esac

echo -n "Enter Quantity (1-10): "
read qty

if [ $qty -lt 1 ] || [ $qty -gt 10 ]
then
    echo "Quantity should be between 1 and 10"
    exit
fi

total=$((price * qty))

if [ $total -lt 500 ]
then
    delivery=50
else
    delivery=0
fi

final=$((total + delivery))

echo
echo "=================================="
echo "         ORDER SUMMARY"
echo "=================================="
echo "Food Item       : $food"
echo "Quantity        : $qty"
echo "Price per Item  : Rs.$price"
echo "Order Amount    : Rs.$total"
echo "Delivery Charge : Rs.$delivery"
echo "----------------------------------"
echo "Final Amount    : Rs.$final"
echo "=================================="
echo "Thank You! Visit Again."
