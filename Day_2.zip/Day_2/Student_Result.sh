echo "======================================="
echo "     STUDENT RESULT EVALUATION SYSTEM"
echo "======================================="

echo -n "Enter Student Name: "
read name

echo -n "Enter Roll Number: "
read roll

echo -n "Enter Marks in Subject 1: "
read m1

echo -n "Enter Marks in Subject 2: "
read m2

echo -n "Enter Marks in Subject 3: "
read m3

echo -n "Enter Marks in Subject 4: "
read m4

echo -n "Enter Marks in Subject 5: "
read m5

total=$((m1+m2+m3+m4+m5))
percentage=$((total/5))

if [ $m1 -ge 35 ] && [ $m2 -ge 35 ] && [ $m3 -ge 35 ] && [ $m4 -ge 35 ] && [ $m5 -ge 35 ]
then
    result="PASS"
else
    result="FAIL"
fi

if [ $percentage -ge 90 ]
then
    grade="A+"
elif [ $percentage -ge 80 ]
then
    grade="A"
elif [ $percentage -ge 70 ]
then
    grade="B"
elif [ $percentage -ge 60 ]
then
    grade="C"
elif [ $percentage -ge 50 ]
then
    grade="D"
elif [ $percentage -ge 35 ]
then
    grade="E"
else
    grade="F"
fi

echo
echo "======================================="
echo "          STUDENT RESULT"
echo "======================================="
echo "Student Name : $name"
echo "Roll Number  : $roll"
echo "---------------------------------------"
echo "Subject 1    : $m1"
echo "Subject 2    : $m2"
echo "Subject 3    : $m3"
echo "Subject 4    : $m4"
echo "Subject 5    : $m5"
echo "---------------------------------------"
echo "Total Marks  : $total / 500"
echo "Percentage   : $percentage%"
echo "Result       : $result"
echo "Grade        : $grade"
echo "======================================="
echo "Thank You!"
