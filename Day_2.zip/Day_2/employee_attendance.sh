NORMAL_HOURS=8

echo "==================================="
echo "Employee Attendance Validation"
echo "==================================="

# Accept employee details
read -p "Enter Employee ID: " empid
read -p "Enter Employee Name: " empname
read -p "Enter Working Hours: " hours

echo ""
echo "Employee Details"
echo "---------------------------"
echo "Employee ID   : $empid"
echo "Employee Name : $empname"
echo "Working Hours : $hours"

# Check attendance
if [ "$hours" -gt "$NORMAL_HOURS" ]; then
    overtime=$((hours - NORMAL_HOURS))

    echo "Status         : Present"
    echo "Overtime Hours : $overtime"
    echo "Message        : Eligible for Overtime"

elif [ "$hours" -eq "$NORMAL_HOURS" ]; then

    echo "Status         : Present"
    echo "Overtime Hours : 0"
    echo "Message        : Normal Working Hours"

elif [ "$hours" -gt 0 ]; then

    echo "Status         : Present"
    echo "Overtime Hours : 0"
    echo "Message        : Worked Less than Normal Hours"

else

    echo "Status         : Absent"
    echo "Overtime Hours : 0"
    echo "Message        : No Working Hours Recorded"

fi
