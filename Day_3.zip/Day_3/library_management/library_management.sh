INPUT_FILE="books.txt"
REPORT_FILE="library_report.txt"

# Check if input file exists
if [ ! -f "$INPUT_FILE" ]; then
    echo "Error: $INPUT_FILE not found."
    exit 1
fi

# Function to determine stock status
check_stock() {
    copies=$1

    if [ "$copies" -ge 6 ]; then
        echo "High Stock"
    elif [ "$copies" -ge 3 ]; then
        echo "Medium Stock"
    else
        echo "Low Stock"
    fi
}

# Create report file
echo "Library Book Report" > "$REPORT_FILE"
echo "---------------------" >> "$REPORT_FILE"

echo "" >> "$REPORT_FILE"
echo "Low Stock Books" >> "$REPORT_FILE"
echo "---------------------" > /tmp/low_stock.tmp

# Read file using loop
while read -r bookid bookname copies
do
    status=$(check_stock "$copies")

    echo "$bookid $bookname $copies Status:$status" >> "$REPORT_FILE"

    if [ "$copies" -lt 3 ]; then
        echo "$bookid $bookname $copies" >> /tmp/low_stock.tmp
    fi

done < "$INPUT_FILE"

echo "" >> "$REPORT_FILE"
echo "Low Stock Books" >> "$REPORT_FILE"
echo "---------------------" >> "$REPORT_FILE"

cat /tmp/low_stock.tmp >> "$REPORT_FILE"

rm -f /tmp/low_stock.tmp

echo "Report generated successfully."
echo "Output file: $REPORT_FILE"
