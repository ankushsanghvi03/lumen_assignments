INPUT_FILE="enrollment.txt"
REPORT_FILE="course_report.txt"

# Check if input file exists
if [ ! -f "$INPUT_FILE" ]; then
    echo "Error: $INPUT_FILE not found."
    exit 1
fi

# Function to identify course type
course_type() {
    case "$1" in
        Python|Java)
            echo "Programming Course"
            ;;
        Linux)
            echo "System Course"
            ;;
        *)
            echo "Other Course"
            ;;
    esac
}

total_revenue=0

# Clear/Create report file
echo "Course Enrollment Report" > "$REPORT_FILE"
echo "-------------------------" >> "$REPORT_FILE"

# Associative array to count enrollments
declare -A course_count

# Read file line by line
while read -r student course fee
do
    type=$(course_type "$course")

    echo "$student enrolled in $course Fee:$fee Type:$type" >> "$REPORT_FILE"

    total_revenue=$((total_revenue + fee))

    ((course_count["$course"]++))

done < "$INPUT_FILE"

echo "-------------------------" >> "$REPORT_FILE"
echo "Total Revenue: $total_revenue" >> "$REPORT_FILE"

echo "" >> "$REPORT_FILE"
echo "Popular Courses" >> "$REPORT_FILE"
echo "-------------------------" >> "$REPORT_FILE"

for course in "${!course_count[@]}"
do
    echo "$course : ${course_count[$course]} student(s)" >> "$REPORT_FILE"
done

echo "Report generated successfully."
echo "Output file: $REPORT_FILE"
