mkdir -p Store/Inventory
mkdir -p Store/Reports
mkdir -p Store/Archive

cp inventory.txt Store/Inventory/

export INVENTORY_DIR=$PWD/Store/Inventory
export REPORT_DIR=$PWD/Store/Reports
export ARCHIVE_DIR=$PWD/Store/Archive

echo "Total Products:"
wc -l < $INVENTORY_DIR/inventory.txt

echo
echo "Inventory Details:"
cat $INVENTORY_DIR/inventory.txt

echo
echo "Low Stock Products:"
awk -F',' '$3<10' $INVENTORY_DIR/inventory.txt > $REPORT_DIR/low_stock_report.txt
cat $REPORT_DIR/low_stock_report.txt

echo
echo "Products Containing 'Rice':"
grep "Rice" $INVENTORY_DIR/inventory.txt

echo
echo "Inventory Report:"
awk -F',' 'BEGIN{
print "ID\tName\tQuantity\tPrice\tValue"
total=0
}
{
value=$3*$4
print $1"\t"$2"\t"$3"\t"$4"\t"value
total+=value
}
END{
print "------------------------------"
print "Total Inventory Value =",total
}' $INVENTORY_DIR/inventory.txt > $REPORT_DIR/inventory_report.txt

cat $REPORT_DIR/inventory_report.txt

sed -i 's/Milk/Fresh Milk/g' $INVENTORY_DIR/inventory.txt

echo
echo "Updated Inventory:"
cat $INVENTORY_DIR/inventory.txt

tar -czf $ARCHIVE_DIR/reports.tar.gz $REPORT_DIR

echo
echo "Archive Created:"
ls -lh $ARCHIVE_DIR

echo
echo "Cron Job Command:"
echo "0 18 * * * $PWD/inventory_management.sh"
