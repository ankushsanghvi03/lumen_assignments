export TARGET_DIR="processed_logs"
export ARCHIVE_NAME="log_backup.tar.gz"

pwd

if [ ! -f "app.log" ]; then
    echo "INFO login successful" > app.log
    echo "ERROR  database failure" >> app.log
fi

ls -l app.log

mkdir -p $TARGET_DIR

cat app.log | grep "ERROR" > $TARGET_DIR/filtered_errors.log
sed -i 's/  / /g' $TARGET_DIR/filtered_errors.log
awk '{print "[ALERT]", $0}' $TARGET_DIR/filtered_errors.log > $TARGET_DIR/final_report.txt
rm $TARGET_DIR/filtered_errors.log

tar -czf $ARCHIVE_NAME $TARGET_DIR
rm -rf $TARGET_DIR

echo "Task executed by user: $(whoami)"
id
ps -f -u $(whoami)

echo "Workflow complete! Archive generated successfully."
