PROJECT_DIR=$(pwd)
DATA_DIR="$PROJECT_DIR/data"
REPORT_DIR="$PROJECT_DIR/reports"
ARCHIVE_DIR="$PROJECT_DIR/archive"
LOG_FILE="$PROJECT_DIR/process_log.txt"

# Create required directories
mkdir -p "$DATA_DIR"
mkdir -p "$REPORT_DIR"
mkdir -p "$ARCHIVE_DIR"

MARKS_FILE="$DATA_DIR/student_marks.txt"
REPORT_FILE="$REPORT_DIR/student_report.txt"

echo "==================================" > "$LOG_FILE"
echo "Student Report Automation Started" >> "$LOG_FILE"
date >> "$LOG_FILE"
echo "==================================" >> "$LOG_FILE"

# Check if marks file exists
if [ ! -f "$MARKS_FILE" ]; then
    echo "Error: student_marks.txt not found." | tee -a "$LOG_FILE"
    exit 1
fi

echo "" >> "$LOG_FILE"
echo "Displaying Student File" >> "$LOG_FILE"
cat "$MARKS_FILE" >> "$LOG_FILE"

echo "" >> "$LOG_FILE"
echo "Students with marks containing 95:" >> "$LOG_FILE"
grep "95" "$MARKS_FILE" >> "$LOG_FILE"

echo "" >> "$LOG_FILE"
echo "Removing Header using sed..." >> "$LOG_FILE"
sed '1d' "$MARKS_FILE" > "$DATA_DIR/temp.txt"

echo "" >> "$LOG_FILE"
echo "Students Sorted by Name" >> "$LOG_FILE"
sort -k2 "$DATA_DIR/temp.txt" >> "$LOG_FILE"

echo "" >> "$LOG_FILE"
echo "Generating Performance Report..." >> "$LOG_FILE"

awk '
BEGIN{
printf "%-5s %-10s %-8s %-8s %-8s %-8s %-8s %-6s\n","ID","Name","Maths","Science","English","Total","Average","Grade";
print "--------------------------------------------------------------------------";
}
{
total=$3+$4+$5;
avg=total/3;

if(avg>=90)
grade="A";
else if(avg>=75)
grade="B";
else if(avg>=60)
grade="C";
else
grade="F";

printf "%-5s %-10s %-8d %-8d %-8d %-8d %-8.2f %-6s\n",$1,$2,$3,$4,$5,total,avg,grade;
}
' "$DATA_DIR/temp.txt" > "$REPORT_FILE"

echo "Report Generated Successfully." >> "$LOG_FILE"

echo "" >> "$LOG_FILE"
echo "Compressing Report..." >> "$LOG_FILE"

gzip -f -k "$REPORT_FILE"

echo "Creating Archive..." >> "$LOG_FILE"

tar -czf "$ARCHIVE_DIR/student_reports.tar.gz" "$REPORT_DIR"

echo "" >> "$LOG_FILE"
echo "Completed Successfully." >> "$LOG_FILE"

rm "$DATA_DIR/temp.txt"

echo "-----------------------------------------"
echo "Student Marks Processing Completed."
echo "Report Location : $REPORT_FILE"
echo "Compressed File : $REPORT_FILE.gz"
echo "Archive         : $ARCHIVE_DIR/student_reports.tar.gz"
echo "Log File        : $LOG_FILE"
echo "-----------------------------------------"
